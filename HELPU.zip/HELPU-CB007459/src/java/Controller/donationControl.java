package Controller;

import Model.DAO;
import Model.websitedonation;
import Model.websiterequest;
import Model.websiteusers;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class donationControl extends HttpServlet {


    
    @Override
    @SuppressWarnings("fallthrough")
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    try {
            String command = request.getParameter("command");
            if (command == null)
            {
                command="PAGE";
            }
            
            switch (command)
            {
                case "PAGE":DonnerPage(request, response);
                break;
                case "HOMED":HomeDonations (request,response);
                break;
                case "LIST":ListDonations(request,response);
                break;
                case "ADD":AddDonations(request,response);
                break;
                case "DELETE":DeleteDonations(request,response);
                break;
                case "VIEWME":ViewMe(request, response);
                break;
                case "SEARCH":SearchDonation(request, response);
                break;
                case "VIEWMYDONATIONS":ViewMyDonations(request, response);
                default:DonnerPage(request, response);      
            }
            
        } catch (Exception ex) {
            Logger.getLogger(donationControl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }
     public void DonnerPage (HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
         
        HttpSession session= request.getSession();
        String user=(String) session.getAttribute("user");
        session.setAttribute("name", user);
   
       
        RequestDispatcher dispatcher = request.getRequestDispatcher("/donnerpage.jsp");
        dispatcher.forward(request,response);
    }
    
    private void ListDonations(HttpServletRequest request,HttpServletResponse response)
            throws Exception{
        
        HttpSession session= request.getSession();
        String donation =(String) session.getAttribute("donation");
        DAO dao = new DAO();
        
        List<websitedonation> donations  = dao.getAllWebsiteDonation();        
        request.setAttribute("DONATION_LIST", donations);
        session.setAttribute("name", donation);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("/listdonations.jsp");
        dispatcher.forward(request, response);
        
    }
    
    private void AddDonations (HttpServletRequest request,HttpServletResponse response)
            throws Exception{ 
        // read data from form
        
        DAO dao = new DAO();
         
        String username = request.getParameter("username");
        String type = request.getParameter("type");
        String phonenumber = request.getParameter("phonenumber");
        String email = request.getParameter("email");       
        String description = request.getParameter("description");
        String donationNO = request.getParameter("donationNO");
        String requestNO = request.getParameter ("requestNO");
       
        
        //creating new user object
        websitedonation donation = new websitedonation(username,type,phonenumber,email,description,donationNO,requestNO);       
        
        //adding user to the database
        dao.addDonation(donation);    
        request.getRequestDispatcher("donnerpage.jsp").forward(request, response);
    }
    
     private void DeleteDonations(HttpServletRequest request, HttpServletResponse response) {
      DAO dao = new DAO();
        
       
        String donationNO = request.getParameter("donationNO");
        
        websitedonation donation = new  websitedonation(donationNO);
        dao.deleteDonation(donationNO);
         try {
            ListDonations(request,response);
        } catch (Exception ex) {
            Logger.getLogger(donationControl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


      public void ViewMe(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        DAO dao = new DAO();


        HttpSession session= request.getSession();
        String user=(String) session.getAttribute("user");
   
        List<websiteusers> searchedUser=dao.selectUser(user);
        request.setAttribute("USER_LIST", searchedUser);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/donnerprofile.jsp");
        dispatcher.forward(request,response);
    }
      
       public void ViewMyDonations(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        DAO dao = new DAO();


        HttpSession session= request.getSession();
        String user =(String) session.getAttribute("user");
   
        List<websitedonation> searchedonation=dao.selectDonation(user);
        request.setAttribute("DONATION_LIST", searchedonation);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/donnerdonations.jsp");
        dispatcher.forward(request,response);
    }
       
       
       private void HomeDonations(HttpServletRequest request,HttpServletResponse response)
            throws Exception{
        
        HttpSession session= request.getSession();
        String donation =(String) session.getAttribute("donation");
        DAO dao = new DAO();
        
        List<websitedonation> donations  = dao.getAllWebsiteDonation();        
        request.setAttribute("DONATION_LIST", donations);
        session.setAttribute("name", donation);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("/homedonations.jsp");
        dispatcher.forward(request, response);
        
    }
       public void SearchDonation(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        DAO dao = new DAO();


        String donationNO =request.getParameter("donationNO");
        List<websitedonation> searchedDonation=dao.selectdonation(donationNO);
        request.setAttribute("DONATION_LIST", searchedDonation);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/viewDonations.jsp");
        dispatcher.forward(request,response);
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
