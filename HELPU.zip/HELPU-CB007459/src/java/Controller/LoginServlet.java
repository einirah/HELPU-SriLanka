package Controller;

import Model.DAO;
import Model.websiteusers;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

  

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {  
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();       
        //get the user name ans password 
        String name = request.getParameter("username");
        String password = request.getParameter("password");
        
        websiteusers user = new  websiteusers (name,password);     
        DAO dao =   new DAO ();       
        String type =null;       
        try {
            //get the user role for the logging user to the user role variable
            type = dao.authonticateUser(user);
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }      
        switch (type) {
            case "Admin":
            {
                //create a new session
                HttpSession session = request.getSession();
                //set the response attribute
                session.setAttribute("user",name);
                //setting session attribute
                response.sendRedirect("userControl");
                break;
            }            
            case "Requester":
            {
                HttpSession session = request.getSession();
                session.setAttribute("user",name);             
                response.sendRedirect("requestController");
                break;
            }            
             case "Donner":
            {
                HttpSession session = request.getSession();
                session.setAttribute("user",name);             
                response.sendRedirect("donationControl");
                break;
            }
            default:
            {
                out.print("Sorry username or password error! Try login again");
                request.getRequestDispatcher("login.html").include(request, response);
                break;
            }       
        }
    }

  
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
