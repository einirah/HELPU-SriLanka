package Controller;

import Model.DAO;
import Model.websiterequest;
import Model.websiteusers;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class requestController extends HttpServlet {


    
    @Override
    @SuppressWarnings("fallthrough")
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    try {
            String command = request.getParameter("command");
            if (command == null)
            {
                command="PAGE";
            }
            
            switch (command)
            {
                case "HOMER":HomeRequests(request,response);
                break;
                case "PAGE":RequesterPage(request, response);
                break;
                case "LIST":ListRequests(request,response);
                break;
                case "ADD":AddRequests(request,response);
                break;
                case "DELETE":DeleteRequests(request,response);
                break;
                case "VERIFY": VerifyRequests (request,response);
                break;
                case "REJECT": RejectRequests (request,response);
                break;
                case "CLOSE": CloseRequests (request,response);
                break;
                case "SEARCH":SearchRequest(request, response);
                break;              
                case "VIEWME":ViewMe(request, response);
                break;
                case "VIEWMYREQUESTS":ViewMyRequests(request, response);
                default:RequesterPage(request, response);        
            }
            
        } catch (Exception ex) {
            Logger.getLogger(userControl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }
    
    public void RequesterPage (HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        
        HttpSession session= request.getSession();
        String user=(String) session.getAttribute("user");
        session.setAttribute("name", user);
   
       
        RequestDispatcher dispatcher = request.getRequestDispatcher("/requesterpage.jsp");
        dispatcher.forward(request,response);
    }
    
    private void ListRequests (HttpServletRequest request,HttpServletResponse response)
            throws Exception{
        
        HttpSession session= request.getSession();
        String userRequest =(String) session.getAttribute("request");
        DAO dao = new DAO();
        
        List<websiterequest> requests  = dao.getAllWebsiteRequest();        
        request.setAttribute("REQUEST_LIST", requests);
        session.setAttribute("name",userRequest);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("/listrequests.jsp");
        dispatcher.forward(request, response);
        
    }
    
    private void AddRequests(HttpServletRequest request,HttpServletResponse response)
            throws Exception{ 
        // read data from form
       
        DAO dao = new DAO();
        
        String username = request.getParameter("username");
        String type = request.getParameter("type");
        String address = request.getParameter("address");
        String phonenumber = request.getParameter("phonenumber");
        String status = request.getParameter("status");       
        String description = request.getParameter("description");
        String requestNO = request.getParameter("requestNO");
       
        
        //creating new user object
        websiterequest userrequest = new websiterequest(username,type,address,phonenumber,status,description,requestNO);       
        
        //adding user to the database
        dao.addRequest( userrequest);
        request.getRequestDispatcher("requesterpage.jsp").forward(request, response);
        
     // ListRequests(request,response);
                }
    
    private void DeleteRequests(HttpServletRequest request, HttpServletResponse response) {
        DAO dao = new DAO();
        
       
        String requestNO = request.getParameter("requestNO");
        
        websiterequest userrequest = new  websiterequest(requestNO);
        dao.deleteRequest(requestNO);                
        try {
            ListRequests(request,response);
        } catch (Exception ex) {
            Logger.getLogger(userControl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void VerifyRequests(HttpServletRequest request, HttpServletResponse response) {
        DAO dao = new DAO();
              
        String requestNO = request.getParameter("requestNO");
        
        websiterequest userrequest = new  websiterequest(requestNO);
        dao.verifyRequest(requestNO);
        try {
            ListRequests(request,response);
        } catch (Exception ex) {
            Logger.getLogger(requestController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void RejectRequests(HttpServletRequest request, HttpServletResponse response) {
      DAO dao = new DAO();
        
       
        String requestNO = request.getParameter("requestNO");
        
        websiterequest userrequest = new  websiterequest(requestNO);
        dao.rejectRequest(requestNO);      
        try {
            ListRequests(request,response);
        } catch (Exception ex) {
            Logger.getLogger(requestController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void CloseRequests(HttpServletRequest request, HttpServletResponse response) {
      DAO dao = new DAO();
        
       
        String requestNO = request.getParameter("requestNO");
        
        websiterequest userrequest = new  websiterequest(requestNO);
        dao.closeRequest(requestNO);
        try {
            ListRequests(request,response);
        } catch (Exception ex) {
            Logger.getLogger(requestController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
      
    public void SearchRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        DAO dao = new DAO();


        String type =request.getParameter("type");
        List<websiterequest> searchedRequest=dao.selectrequest(type);
        request.setAttribute("REQUEST_LIST", searchedRequest);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/SearchRequestDonner.jsp");
        dispatcher.forward(request,response);
    }
    
   
    
    public void ViewMe(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        DAO dao = new DAO();


        HttpSession session= request.getSession();
        String user=(String) session.getAttribute("user");
   
        List<websiteusers> searchedUser=dao.selectUser(user);
        request.setAttribute("USER_LIST", searchedUser);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/requesterprofile.jsp");
        dispatcher.forward(request,response);
    }
    
    public void ViewMyRequests(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        DAO dao = new DAO();


        HttpSession session= request.getSession();
        String userRequests =(String) session.getAttribute("user");
   
        List<websiterequest> searchedRequest=dao.selectRequest(userRequests);
        request.setAttribute("REQUEST_LIST", searchedRequest);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/requesterrequests.jsp");
        dispatcher.forward(request,response);
    }
    
    private void HomeRequests (HttpServletRequest request,HttpServletResponse response)
            throws Exception{
        
        HttpSession session= request.getSession();
        String userRequest =(String) session.getAttribute("request");
        DAO dao = new DAO();
        
        List<websiterequest> Arequests  = dao.getAcceptedRequests();        
        request.setAttribute("REQUEST_LIST", Arequests);
        session.setAttribute("name",userRequest);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("/homerequests.jsp");
        dispatcher.forward(request, response);
        
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
