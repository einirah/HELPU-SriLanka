package Controller;

import Model.DAO;
import Model.websiteusers;
import Model.Inquire;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class userControl extends HttpServlet {


    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    try {
            String command = request.getParameter("command");
            if (command == null)
            {
                command="LIST";
            } 
           
            switch (command)
            {
                
                case "LIST":ListUsers(request,response);
                break;
                case "ADD":AddUsers(request,response);
                break;
                case "DELETE":DeleteUsers(request,response);
                break;
                case "SEARCH":SearchUser(request, response);
                break;
                case "VIEWME":ViewMe(request, response);
                break;
                case "INQUIRE":Inquire(request,response);              
                default:ListUsers(request,response);   
            } 
            
        } catch (Exception ex) {
            Logger.getLogger(userControl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }
    
    private void ListUsers(HttpServletRequest request,HttpServletResponse response)
            throws Exception{
        
        HttpSession session= request.getSession();
        String user=(String) session.getAttribute("user");       
        DAO dao = new DAO();
        
        List<websiteusers>users = dao.getAllWebsiteUsers();        
        request.setAttribute("USER_LIST", users);
        session.setAttribute("name", user);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("/adminPage.jsp");
        dispatcher.forward(request, response);
        
    }
    
    private void AddUsers (HttpServletRequest request,HttpServletResponse response)
            throws Exception{ 
        // read data from form
        DAO dao = new DAO();
        
        String username = request.getParameter("username");
        String fullname = request.getParameter("fullname");
        String email = request.getParameter("email");       
        String type = request.getParameter("type");
        String phonenumber = request.getParameter("phonenumber");
        String address = request.getParameter("address");
        String password = request.getParameter ("password");
        
        //creating new user object
        websiteusers user = new websiteusers(username,fullname,email,type,phonenumber,address,password);       
        
        //adding user to the database
        dao.addUser(user);
        
        //after registeration take the user to login page 
        request.getRequestDispatcher("login.html").forward(request, response);
                }
    
     private void DeleteUsers(HttpServletRequest request, HttpServletResponse response) {
      DAO dao = new DAO();
        
        String username = request.getParameter("username");
        
        websiteusers user = new websiteusers(username);
        dao.deleteUser(username);
        
    
        
        try {
            ListUsers(request,response);
        } catch (Exception ex) {
            Logger.getLogger(userControl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

     public void SearchUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        DAO dao = new DAO();

        
      String user =request.getParameter("username");
      List<websiteusers> searchedUser=dao.selectUser(user);
      request.setAttribute("USER_LIST", searchedUser);
      RequestDispatcher dispatcher = request.getRequestDispatcher("/SearchUserAdmin.jsp");
      dispatcher.forward(request,response);
    }

    public void ViewMe(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Exception {
        DAO dao = new DAO();


        HttpSession session= request.getSession();
        String user=(String) session.getAttribute("user");
    
        List<websiteusers> searchedUser=dao.selectUser(user);
        request.setAttribute("USER_LIST", searchedUser);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/adminprofile.jsp");
        dispatcher.forward(request,response);
    }
    
    private void Inquire (HttpServletRequest request,HttpServletResponse response)
            throws Exception{ 
        // read data from form
        DAO dao = new DAO();
        
       
        String fullname = request.getParameter("fullname");
        String email = request.getParameter("email");       
        String inquire = request.getParameter ("inquire");
        
        //creating new inquiry object
        Inquire inq = new Inquire(fullname,email,inquire);       
        
        //adding inquiries to the database
        dao.addInquire(inq);  
        request.getRequestDispatcher("home.jsp").forward(request, response);
                }
    
     
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
