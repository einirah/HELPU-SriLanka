package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
    public static Connection getConnection(){
            String URL  = "jdbc:mysql://localhost:3306/mysql";
            String username = "root";
            String password = null; 
        
        
        try {
          
            Class.forName("com.mysql.jdbc.Driver");
            Connection con =  DriverManager.getConnection(URL,username,password);
            return con;
        } catch (ClassNotFoundException | SQLException ex) {
            
            // this connection stays available with the string to be connected to any users.
            System.out.println("Database.getConnection() Error -->"+ ex.getMessage());
            return null;
        }
              
    }
    public static void close(Connection con){
        try{
            con.close();
            
        }
        catch(SQLException ex){
            
        }
    }

}
