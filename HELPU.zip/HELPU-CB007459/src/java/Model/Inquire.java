
package Model;

public class Inquire {
    String fullname,email,inquiry;

    public Inquire(String fullname, String email, String inquiry) {
        this.fullname = fullname;
        this.email = email;
        this.inquiry = inquiry;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getInquiry() {
        return inquiry;
    }

    public void setInquiry(String inquiry) {
        this.inquiry = inquiry;
    }
    
    
}
