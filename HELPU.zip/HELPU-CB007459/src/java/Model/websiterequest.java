package Model;

public class websiterequest {
    String username,type,address,phonenumber,status,description,requestNO;

    public websiterequest(String requestNO) {
        this.requestNO = requestNO;
    }

    public websiterequest(String username, String type, String address, String phonenumber, String status, String description, String requestNO) {
        this.username = username;
        this.type = type;
        this.address = address;
        this.phonenumber = phonenumber;
        this.status = status;
        this.description = description;
        this.requestNO = requestNO;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRequestNO() {
        return requestNO;
    }

    public void setRequestNO(String requestNO) {
        this.requestNO = requestNO;
    }
    
}
