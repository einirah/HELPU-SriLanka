
package Model;

public class websitedonation {
     String username,type,phonenumber,email,description,donationNO,requestNO;

    public websitedonation(String username) {
        this.username = username;
    }

    public websitedonation(String type, String description, String donationNO) {
        this.type = type;
        this.description = description;
        this.donationNO = donationNO;
    }

    public websitedonation(String username, String type, String phonenumber, String email, String description, String donationNO,String requestNO) {
        this.username = username;
        this.type = type;
        this.phonenumber = phonenumber;
        this.email = email;
        this.description = description;
        this.donationNO = donationNO;
        this.requestNO = requestNO;
    }

    public String getRequestNO() {
        return requestNO;
    }

    public void setRequestNO(String requestNO) {
        this.requestNO = requestNO;
    }

   

    public String getDonationNO() {
        return donationNO;
    }

    public void setDonationNO(String donationNO) {
        this.donationNO = donationNO;
    }

    

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
     

}