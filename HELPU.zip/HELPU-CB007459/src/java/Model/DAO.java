package Model;

import Model.Database;
import Controller.userControl;
import Model.websiteusers;
import Model.websiterequest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class DAO {
    private final Connection connection;
    
    public DAO(){
        connection = Database.getConnection();
    }
    
    
    //USERS
    public List<websiteusers> getAllWebsiteUsers(){
        List<websiteusers> users = new ArrayList<websiteusers>();
        try{
            //create sql statement
            PreparedStatement ps = connection.prepareStatement("select * from websiteusers");
            
      
            
            //execute 
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                

                String username = rs.getString("username");
                String fullname = rs.getString("fullname");
                String email = rs.getString("email");
                String type = rs.getString("type");
                String phonenumber = rs.getString("phonenumber");
                String address = rs.getString("address");
                String password = rs.getString("password");
               
                websiteusers user = new websiteusers (username,fullname,email,type,phonenumber,address,password);
               
                users.add(user); //adding objects of user to the arraylist
            }
            
        }catch (SQLException e){
            e.printStackTrace();
        }
        return users;
       
    }
    public void addUser (websiteusers user) {
        try {
        // adding the onject of user and the data entered regarding to that in the database
        PreparedStatement preparedStatement = connection.prepareStatement
        ("insert into websiteusers values(?,?,?,?,?,?,?)");                
        
        preparedStatement.setString(1,user.getUsername());       
        preparedStatement.setString(2,user.getFullname());
        preparedStatement.setString(3,user.getEmail());
        preparedStatement.setString(4,user.getType());
        preparedStatement.setString(5,user.getPhonenumber());
        preparedStatement.setString(6,user.getAddress());
        preparedStatement.setString(7,user.getPassword());
        preparedStatement.executeUpdate();
        
        }catch (SQLException e){
            e.printStackTrace();
        }       
    }    
    public void deleteUser (String username) {
            try{
            PreparedStatement preparedStatement = connection.prepareStatement("delete from websiteusers where username=?");
        
        preparedStatement.setString(1,username);
        preparedStatement.executeUpdate();
        
            } catch (SQLException e){
            e.printStackTrace();
        }
        }
    public String authonticateUser (websiteusers user) throws SQLException {
        String username = user.getUsername();
        String password = user.getPassword();
        
        try {
            PreparedStatement ps = connection.prepareStatement("select username,type, password from websiteusers");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                
                String NAME = rs.getString("username");
                String ROLE = rs.getString("type");
                String PWD = rs.getString("password");
                
                if (username.equals(NAME) && password.equals(PWD) && ROLE.equalsIgnoreCase("Admin")) 
                    return "Admin";
                else if (username.equals(NAME) && password.equals(PWD) && ROLE.equalsIgnoreCase("Requester")) 
                    return "Requester";
                else if (username.equals(NAME) && password.equals(PWD) && ROLE.equalsIgnoreCase("Donner")) 
                    return "Donner";                 
            } 
        }catch (Exception e) {
                e.printStackTrace ();
        }
        
        return "Invalid";
       }
    public List<websiteusers> selectUser(String username) throws SQLException{

        List<websiteusers> users= new ArrayList<websiteusers>();
        PreparedStatement preparedStatement = connection.prepareStatement("select * from websiteusers where username=?");

        preparedStatement.setString(1, username);
        ResultSet rs = preparedStatement.executeQuery();
        while(rs.next()){
                String uname = rs.getString("username");
                    String fullname = rs.getString("fullname");
                    String email = rs.getString("email");
                    String type = rs.getString("type");
                    String phonenumber = rs.getString("phonenumber");
                    String address = rs.getString("address");
                    String password = rs.getString("password");
            websiteusers user = new websiteusers (uname,fullname,email,type,phonenumber,address,password);
            users.add(user);


        }return users;
    }
    public void addInquire (Inquire inq) {
        try {
        
        PreparedStatement preparedStatement = connection.prepareStatement
        ("insert into inquire values(?,?,?)");                
                     
        preparedStatement.setString(1,inq.getFullname());
        preparedStatement.setString(2,inq.getEmail());
        preparedStatement.setString(3,inq.getInquiry());      
        preparedStatement.executeUpdate();
        
        }catch (SQLException e){
            e.printStackTrace();
        }       
    }  
    public List<Inquire> getAllInquiries(){
        List<Inquire> inquiries = new ArrayList<Inquire>();
        try{
            //create sql statement
            PreparedStatement ps = connection.prepareStatement("select * from inquire");
            //execute 
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                String fullname = rs.getString("fullname");
                String email = rs.getString("email");
                String inquire = rs.getString("inquiry");
                Inquire inq = new Inquire (fullname,email,inquire);              
                inquiries.add(inq); //adding objects of user to the arraylist
            }            
        }catch (SQLException e){
            e.printStackTrace();
        }
        return inquiries;      
    }
   //Donations
    public List<websitedonation> getAllWebsiteDonation(){
        List<websitedonation> donations= new ArrayList<websitedonation>();
        try{
            //create sql statement
            PreparedStatement ps = connection.prepareStatement
            ("select * from websitedonation");           
            //execute 
            ResultSet rs = ps.executeQuery();
            while(rs.next()){                
                String username = rs.getString("username");
                String type = rs.getString("type");              
                String phonenumber = rs.getString("phonenumber");
                String email = rs.getString("email");               
                String description = rs.getString("description");
                String donationNO = rs.getString("donationNO");
                String requestNO = rs.getString("requestNO");
                websitedonation donation = new websitedonation(username,type,phonenumber,email,description,donationNO,requestNO);
                donations.add(donation); //adding objects of user to the arraylist
            }           
        }catch (SQLException e){
            e.printStackTrace();
        }
        return donations;       
    }
    public void addDonation(websitedonation donation) {
        try {
        
        PreparedStatement preparedStatement = connection.prepareStatement
        ("insert into websitedonation values(?,?,?,?,?,?,?)");
        preparedStatement.setString(1,donation.getUsername());
        preparedStatement.setString(2,donation.getType());       
        preparedStatement.setString(3,donation.getPhonenumber());
        preparedStatement.setString(4,donation.getEmail());       
        preparedStatement.setString(5,donation.getDescription());
        preparedStatement.setString(6,donation.getDonationNO());
        preparedStatement.setString(7,donation.getRequestNO());
        preparedStatement.executeUpdate();
        
        }catch (SQLException e){
            e.printStackTrace();
        }        
        }    
    public void deleteDonation (String donationNO) {
        try{
        PreparedStatement preparedStatement = connection.prepareStatement
        ("delete from websitedonation where donationNO=?");
        
       
        preparedStatement.setString(1,donationNO);
        
        preparedStatement.executeUpdate();
        
            } catch (SQLException e){
            e.printStackTrace();
        }
        }
    public List<websitedonation> selectDonation(String username) throws SQLException{
    List<websitedonation> donations= new ArrayList<websitedonation>();
    
    try{
    PreparedStatement preparedStatement = connection.prepareStatement("select * from websitedonation where username=?");
    
    preparedStatement.setString(1, username);
    ResultSet rs = preparedStatement.executeQuery();
    while(rs.next()){
                String uname = rs.getString("username");
                String type = rs.getString("type");              
                String phonenumber = rs.getString("phonenumber");
                String email = rs.getString("email");               
                String description = rs.getString("description");
                String donationNO = rs.getString("donationNO");
                String requestNO = rs.getString("requestNO");
                websitedonation donation = new websitedonation(uname,type,phonenumber,email,description,donationNO,requestNO);
                donations.add(donation); //adding objects of user to the arraylist
            }
    }catch (SQLException e){
            e.printStackTrace();
        }
        return donations;
    }
    public List<websitedonation> selectdonation(String donationNO) throws SQLException{
    List<websitedonation> donations= new ArrayList<websitedonation>();
    
    try{
    PreparedStatement preparedStatement = connection.prepareStatement
        ("select * from websitedonation where donationNO=?");    
    preparedStatement.setString(1, donationNO);
    ResultSet rs = preparedStatement.executeQuery();
    while(rs.next()){
                String uname = rs.getString("username");
                String type = rs.getString("type");              
                String phonenumber = rs.getString("phonenumber");
                String email = rs.getString("email");               
                String description = rs.getString("description");
                String donationNo = rs.getString("donationNO");
                String requestNO = rs.getString("requestNO");
                websitedonation donation = new websitedonation(uname,type,phonenumber,email,description,donationNo,requestNO);
                donations.add(donation); //adding objects of user to the arraylist
            }
    }catch (SQLException e){
            e.printStackTrace();
        }
        return donations;
    }
    
    //Requests
    public List<websiterequest> getAllWebsiteRequest(){
        List<websiterequest> requests= new ArrayList<websiterequest>();
        try{
            //create sql statement
            PreparedStatement ps = connection.prepareStatement("select * from websiterequest");
            
            //execute 
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                
                String username = rs.getString("username");
                String type = rs.getString("type"); 
                String address = rs.getString("address"); 
                String phonenumber = rs.getString("phonenumber");
                String status = rs.getString("status");               
                String description = rs.getString("description");
                String requestNO = rs.getString("requestNO");
                websiterequest request = new websiterequest(username,type,address,phonenumber,status,description,requestNO);
                requests.add(request); //adding objects of user to the arraylist
                
            }
            
        }catch (SQLException e){
            e.printStackTrace();
        } return requests;
       
    }
    public void addRequest(websiterequest request) {
        try {
        
        PreparedStatement preparedStatement = connection.prepareStatement("insert into websiterequest values(?,?,?,?,?,?,?)");
        preparedStatement.setString(1,request.getUsername());
        preparedStatement.setString(2,request.getType());
        preparedStatement.setString(3,request.getAddress());
        preparedStatement.setString(4,request.getPhonenumber());
        preparedStatement.setString(5,"PENDING");       
        preparedStatement.setString(6,request.getDescription());
        preparedStatement.setString(7,request.getRequestNO());
        preparedStatement.executeUpdate();
        
        }catch (SQLException e){
            e.printStackTrace();
        }
        
        }    
    public void deleteRequest (String requestNO) {
            try{
            PreparedStatement preparedStatement = connection.prepareStatement
            ("delete from websiterequest where requestNO=?");             
            preparedStatement.setString(1,requestNO);       
            preparedStatement.executeUpdate();

                } catch (SQLException e){
                e.printStackTrace();
        }
    }
    public void verifyRequest (String requestNO) {
            try{
            PreparedStatement preparedStatement = connection.prepareStatement
            ("update websiterequest set status = 'Accepted' where requestNO=?");              
            preparedStatement.setString(1,requestNO);        
            preparedStatement.executeUpdate();        
            } catch (SQLException e){
            e.printStackTrace();
        }    
    }
    public void rejectRequest (String requestNO) {
            try{
            PreparedStatement preparedStatement = connection.prepareStatement
            ("update websiterequest set status = 'Rejected' where requestNO=?");              
            preparedStatement.setString(1,requestNO);       
            preparedStatement.executeUpdate();
        
            } catch (SQLException e){
            e.printStackTrace();
        }   
    }
    public void closeRequest (String requestNO) {
        try{
            PreparedStatement preparedStatement = connection.prepareStatement
            ("update websiterequest set status = 'Closed',description = 'COMPLETED' where requestNO=?");              
            preparedStatement.setString(1,requestNO);        
            preparedStatement.executeUpdate();       
            } catch (SQLException e){
            e.printStackTrace();
        }   
    }
    public List<websiterequest> selectRequest(String username) throws SQLException{
    List<websiterequest> requests= new ArrayList<websiterequest>();
    PreparedStatement preparedStatement = connection.prepareStatement("select * from websiterequest where username=?");
    
    preparedStatement.setString(1, username);
    ResultSet rs = preparedStatement.executeQuery();
    while(rs.next()){
                String uname = rs.getString("username");
                String role = rs.getString("type"); 
                String address = rs.getString("address"); 
                String phonenumber = rs.getString("phonenumber");
                String status = rs.getString("status");               
                String description = rs.getString("description");
                String requestNO = rs.getString("requestNO");
                websiterequest Request = new websiterequest(uname,role,address,phonenumber,status,description,requestNO);
        
        requests.add(Request);
    }return requests;
    }
    public List<websiterequest> getAcceptedRequests(){
        List<websiterequest> Arequests= new ArrayList<websiterequest>();
        try{
            //create sql statement
            PreparedStatement ps = connection.prepareStatement("select * from websiterequest where status ='Accepted'");
            
            //execute 
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                
                String username = rs.getString("username");
                String type = rs.getString("type"); 
                String address = rs.getString("address"); 
                String phonenumber = rs.getString("phonenumber");
                String status = rs.getString("status");               
                String description = rs.getString("description");
                String requestNO = rs.getString("requestNO");
                websiterequest request = new websiterequest(username,type,address,phonenumber,status,description,requestNO);
                Arequests.add(request); //adding objects of user to the arraylist
                
            }
            
        }catch (SQLException e){
            e.printStackTrace();
        } return Arequests;
       
    }  
    public List<websiterequest> selectrequest (String type) throws SQLException{
    List<websiterequest> requests = new ArrayList<websiterequest>();
    PreparedStatement preparedStatement = connection.prepareStatement
        ("select * from websiterequest where type=?");
    
    preparedStatement.setString(1, type);
    ResultSet rs = preparedStatement.executeQuery();
    while(rs.next()){
                String username = rs.getString("username");
                String role = rs.getString("type"); 
                String address = rs.getString("address"); 
                String phonenumber = rs.getString("phonenumber");
                String status = rs.getString("status");               
                String description = rs.getString("description");
                String requestNO = rs.getString("requestNO");
                websiterequest Request = new websiterequest(username,role,address,phonenumber,status,description,requestNO);
                requests.add(Request);
               }return requests;
    }
    
   
    
}
